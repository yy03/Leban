create
    definer = `skip-grants user`@`skip-grants host` procedure GreetWorld()
SELECT CONCAT(@gretting, 'World!');

